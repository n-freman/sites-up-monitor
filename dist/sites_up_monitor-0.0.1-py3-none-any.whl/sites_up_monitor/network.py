import socket
from collections import namedtuple
from contextlib import closing

from pythonping import ping


Address = namedtuple('Address', ['ip', 'port'])


class Networker:
    def fetch_ips(self, host_name):
        try:
            return socket.gethostbyname_ex(host_name)
        except:
            raise FetchIpsError('Couldn\'t fetch ip addresses')
        
    def is_port_open(self, host, port):
        with closing(socket.socket(socket.AF_INET, socket.SOCK_STREAM)) as sock:
            sock.settimeout(10)
            return sock.connect_ex((host, port)) == 0
    
    def ping(self):
        ...


class FetchIpsError(Exception):
    pass


class Site:
    def __init__(self, host_name, ip_addresses):
        self.host_name = host_name
        self.ip_addresses = ip_addresses
    