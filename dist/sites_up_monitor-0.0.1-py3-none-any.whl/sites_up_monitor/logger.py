from typing import *


class Logger:
    def __init__(self):
        ...

    def log(self, data: Mapping[str, str]):
        ...

