from .logger import Logger
from .reader import Reader
from . import config as conf


class App():
    def __init__(self):
        self.reader = Reader(conf.INPUT_DATA_FILE_LOC)
        self.logger = Logger()

    def run(self):
        reader.read()


app = App()

if __name__ == '__main__':
    app.run()
